#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <qcustomplot.h>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }

class QUdpSocket;
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QByteArray commingdata;
  QByteArray x;

 // QByteArray j;s+q+w+o+qr+qt+y
   QString s;
   QString q;
   QString w;
   QString o;
   QString qr;
 QString j;
   QString qt;
   QString y;
  void setupRealtimeDataDemo(QCustomPlot *customPlot);
   void setupRealtimeDataDemo1(QCustomPlot *customPlot1);
     void setupRealtimeDataDemo2(QCustomPlot *customPlot2);
          void setupRealtimeDataDemo3(QCustomPlot *customPlot3);
   int n;
private slots:
    void on_connect_clicked();

    //void on_Disconnect_clicked();
   void mytime();



   //void on_lcdNumber_overflow();

   //void on_listWidget_2_activated(const QModelIndex &index);

  // vo//id on_listWidget_activated(const QModelIndex &index);

   //void on_pushButton_clicked();

  void on_pushButton_clicked();







//  void on_checkBox_clicked();
//  void setupRealtimeDataDemo(QCustomPlot *customPlot);
  void realtimeDataSlot();
  void realtimeDataSlot1();
 void realtimeDataSlot2();
  void realtimeDataSlot3();
//  void makePlot();
 // void on_checkBox_3_clicked(bool checked);

  //void on_checkBox_3_pressed();

 // void on_checkBox_pressed();

 // void on_checkBox_toggled(bool checked);

  void on_actionAbout_triggered();


  //void on_pushButton_2_clicked();

  void on_rescale_clicked();

  void on_resize1_clicked();

  void on_resize2_clicked();

  void on_resize3_clicked();

  void on_pushButton_2_clicked();

  void on_pushButton_3_clicked();

  void on_pushButton_4_clicked();

  void on_pushButton_5_clicked();

private:
    Ui::MainWindow *ui;
    QUdpSocket *mSocket;
    QTimer *timer;
    QString demoName;
    QTimer dataTimer;
    QCPItemTracer *itemDemoPhaseTracer;
    int currentDemoIndex;


};
#endif // MAINWINDOW_H
