latest update:  14 February 2020

to build the soruce files 
1. install qt creator
2. install qcustomplot package https://www.qcustomplot.com/index.php/download
3. to package as an app-image check linuxdeployqt


for suggestions and query contact 

faizanbhatt427@gmail.com
