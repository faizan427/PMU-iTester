#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QUdpSocket>
#include <iostream>
//using namespace std;
#include <QDebug>
#include <string>
#include <QDateTime>
#include <QListWidget>
#include"QListWidget"
#include <QDesktopWidget>
#include <QScreen>
#include <QMessageBox>
#include <QMetaEnum>
#include <QSharedPointer>
QString HexToAscii(QString Str);
QString HexToFloat(QByteArray z);

int bit_chck, mb,nd;
float frcsec4, time_stamp, fctr2;
double ssh, key;
double kkl,ttl,mag_1,fi_1,mag_2,fi_2,mag_3,fi_3,an_1,an_2,freq,mag__min, mag__max,ang__min,ang__max,an__min,an__max;
QString abc,def,ijk,lmn,opq,rst,uvw,xyz,sk,zyx,wvu,tsr,qpo,nml,kji,fed,cba,bac,edf,jik,mln,poq,srt,vuw,jzz,ipd,jz,phsr_name_01,phsr_name_02,phsr_name_03,an_name_01,an_name_02;//,bgf,sdf,mju,fur,dad,jad;
QString sync_word, frame_size, pmu_id, foc, rofst, pmu_blocks, station_name, frmt, num_phsr, num_an, num_dig, phsr_name_1, phsr_name_2, phsr_name_3,an_name_1, an_name_2,
phsr_con_fctr_1, phsr_con_fctr_2, phsr_con_fctr_3, an_con_fctr_1, an_con_fctr_2,r_o_t, chksum;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)

{
    ui->setupUi(this);
    QPixmap pic ("/home/faizanbhatt/Downloads/340366d5-06a3-4b45-8028-c21b454781f9_200x200.png");
    ui->label_4->setPixmap(pic);


 //layout()->setMargin(0);

    //  setGeometry(400, 250, 542, 390);
      setupRealtimeDataDemo(ui->customPlot);
      realtimeDataSlot();
      setupRealtimeDataDemo1(ui->customPlot1);
      realtimeDataSlot1();
      setupRealtimeDataDemo2(ui->customPlot2);
      realtimeDataSlot2();
      setupRealtimeDataDemo3(ui->customPlot3);
      realtimeDataSlot3();

      setWindowTitle("iTester");
     statusBar()->clearMessage();
      //currentDemoIndex = demoIndex;
      ui->customPlot->replot();



       timer =new QTimer(this);
       connect(timer, SIGNAL(timeout()),this,SLOT(mytime()));
       timer->start(1000);
       mSocket = new QUdpSocket(this);

       connect(mSocket, &QUdpSocket::readyRead, [&](){
           if (mSocket->hasPendingDatagrams()){



        QByteArray commingdata;
             commingdata.resize(mSocket->pendingDatagramSize());
           mSocket->readDatagram(commingdata.data(),commingdata.size());
   bool valid= true;
           QByteArray x;
           x = commingdata.toHex();
            QString j=x;//getting the hex values of packets into a string j

            QString ta =j.mid(0,4);
             QByteArray tb = ta.toUtf8();
             int n;
             n = tb.toLongLong(&valid,16);

           //  ui->listWidget_2->clear();
             // ui->listWidget_2->addItem(j.mid(0,308));
//****************************************Data Parsing Starts From here For both configuaration as well as data frames*************************************


          if (n == 43521)      {


           /*-----------------------------for data frames------------------------*/





     bool valid= true;



        //   QString st= j.mid(13,8);// picking values from index 13 upto 8 indexes and storing those into string st
     QString s= "";
      s+="\nSynchronisation Word:  "+j[0]+j[1]+j[2]+j[3];//+"\nStat:"+j[33]+"Frame Size: "+j[32];


           QString sx =j.mid(4,4);//picking values from index 4 upto 4 indexes and storing those into string

            QByteArray z= sx.toUtf8();// converting string  into a QByte array
            QString i=QString::number(z.toLongLong(&valid,16));//fnc returns int values & get stored into string
            QString q= " ";//declaration of string
            q+= "\nFrame Size:"+i;// definition of string


            QString sd =j.mid(8,4);//picking values from index 8 upto 4 indexes and storing those into string
             QByteArray zd= sd.toUtf8();//converting string  into a QByte array
             QString id=QString::number(zd.toLongLong(&valid,16));//fnc returns int values & get stored into string
             QString w= " ";//declaration of string
             w+= "\nPMU/DC ID Number:"+id;// definition of string




             QString frcsec =j.mid(22,6);//picking values from index 8 upto 4 indexes and storing those into string
              QByteArray frcsec1= frcsec.toUtf8();//converting string  into a QByte array
              QString frcsec2=QString::number(frcsec1.toLongLong(&valid,16));//fnc returns int values & get stored into string
              QString frcsec3= " ";//declaration of string
              frcsec3+= "\n Fractions of Seconds:  "+frcsec2;// definition of string

                  frcsec4 = frcsec2.toFloat(&valid);



             QString o=" ";
             //QString str = " ";

             qint64 qiTimestamp=QDateTime::currentMSecsSinceEpoch();
             QDateTime dt;
             dt.setTime_t(qiTimestamp/1000.0);

             o+="\nTime Stamp:  "+ dt.toString("yyyy-MM-dd hh:mm:ss");
             QString ipd;
             ipd =o;


             if ( nd == 3 && mb == 15)   {

                 QString lmg =j.mid(32,8);//picking values from index  upto  indexes and storing those into string
                  QByteArray mlk= lmg.toUtf8();//converting string  into a QByte array
                  QString kgf = HexToFloat(mlk);

                  QString bgf= " ";//declaration of string w
                  bgf+= phsr_name_1 + "Magnitude #1:   "+kgf;// definition of string w
                    mag_1 = kgf.toFloat(&valid);






                  QString klj =j.mid(40,8);//picking values from index  upto  indexes and storing those into string
                   QByteArray poi= klj.toUtf8();//converting string  into a QByte array
                   QString rty = HexToFloat(poi);

                   QString sdf= " ";//declaration of string
                   sdf+= phsr_name_1 + "Phasor Angle #1:   "+rty;// definition of string
                   fi_1 = rty.toFloat(&valid);


                   QString uio =j.mid(48,8);//picking values from index  upto  indexes and storing those into string
                    QByteArray pgh= uio.toUtf8();//converting string  into a QByte array
                    QString lfj = HexToFloat(pgh);

                    QString mju= " ";//declaration of string
                    mju+= phsr_name_2 + " Magnitude #2:   "+lfj;// definition of string w
                           mag_2= lfj.toFloat(&valid);

                    QString tur =j.mid(56,8);//picking values from index  upto  indexes and storing those into string
                     QByteArray nur= tur.toUtf8();//converting string  into a QByte array
                     QString sur = HexToFloat(nur);

                     QString fur= " ";//declaration of string
                     fur+= phsr_name_2 + "Phasor Angle #2:   "+sur;// definition of string
                               fi_2= sur.toFloat(&valid);


                     QString lad =j.mid(64,8);//picking values from index upto  indexes and storing those into string
                      QByteArray bad= lad.toUtf8();//converting string  into a QByte array
                      QString sad = HexToFloat(bad);

                      QString dad= " ";//declaration of string
                      dad+= phsr_name_3 + " Magnitude #3:   "+sad;// definition of string
                               mag_3 = sad.toFloat(&valid);

                      QString nad =j.mid(72,8);//picking values from index upto indexes and storing those into string
                       QByteArray mad= nad.toUtf8();//converting string into a QByte array
                       QString kad = HexToFloat(mad);

                       QString jad= " ";//declaration of string
                       jad+= phsr_name_3 + " Phasor Angle #3:   "+kad;// definition of string
                                  fi_3 = kad.toFloat(&valid);

                       QString wr=j.mid(80,8);
                       QByteArray lk= wr.toUtf8();//converting string  into a QByte array
                       sk = HexToFloat(lk);
                       QString qr=" ";
                       qr+= "\nFrequency (Floating Point) IEEE 754 Standard: "+sk;
                       freq = sk.toFloat(&valid);


                       QString wt=j.mid(88,8);
                       QByteArray to= wt.toUtf8();//converting string  into a QByte array
                       QString mo = HexToFloat(to);
                        QString qt=" ";
                        qt+= "\nDFREQ / ROCOF:  "+mo;



                        QString lol=j.mid(96,8);
                        QByteArray kop= lol.toUtf8();//converting string  into a QByte array
                        QString set = HexToFloat(kop);
                         QString bt=" ";
                         bt+= an_name_1 + "Analog Value #1: "+set;
                          an_1 = set.toFloat(&valid);


                         QString sop=j.mid(104,8);
                         QByteArray pos= sop.toUtf8();//converting string  into a QByte array
                         QString mom = HexToFloat(pos);
                          QString son=" ";
                          son+= an_name_2 + "Analog Value #2: "+mom;
                            an_2 = mom.toFloat(&valid);



                        QString y= "";
                        y+="\nCheckSum:  0x"+j[112]+j[113]+j[114]+j[115];

                        QString bd= " ";
                        bd += "\n-------------------------------------------------------------------------------";
 ui->listWidget->clear();


                       ui->listWidget->addItem(s+q+w+ipd+frcsec3+bgf+sdf+mju+fur+dad+jad+qr+qt+bt+son+y+bd/*+HexToAscii(st))*/);


             } else if (nd == 3 && mb == 14) {



                 float arg_1, arg_2;


                 QString lmg =j.mid(32,8);//picking values from index 8 upto 4 indexes and storing those into string sd
                  QByteArray mlk= lmg.toUtf8();//converting string sd into a QByte array zd
                  QString kgf = HexToFloat(mlk);
                 // QString kgf=QString::number(mlk.toLongLong(&valid,16));//fnc returns int values & get stored into string id
                  QString bgf= " ";//declaration of string w
                  bgf+= "\n Real::Part #1:   "+kgf;// definition of string w
                  float re_1 = kgf.toFloat(&valid);



                  QString klj =j.mid(40,8);//picking values from index  upto  indexes and storing those into string
                   QByteArray poi= klj.toUtf8();//converting string into a QByte array
                   QString rty = HexToFloat(poi);
                     QString sdf= " ";//declaration of string
                   sdf+= "\n Imaginary::Part #1:   "+rty;// definition of string

                      float im_1 = rty.toFloat(&valid);
                      arg_1 = re_1*re_1+im_1*im_1;
                      arg_2 = re_1/im_1;


                      mag_1 = qSqrt(arg_1);

                      float ratio = 180/3.14;


                     fi_1 = (ratio)*(qAtan(arg_2));



                   QString uio =j.mid(48,8);//picking values from index upto  indexes and storing those into string
                    QByteArray pgh= uio.toUtf8();//converting string  into a QByte array
                    QString lfj = HexToFloat(pgh);

                    QString mju= " ";//declaration of string
                    mju+= "\n Real::Part #2:   "+lfj;// definition of string

                     float re_2 = lfj.toFloat(&valid);

                    QString tur =j.mid(56,8);//picking values from index  upto  indexes and storing those into string
                     QByteArray nur= tur.toUtf8();//converting string  into a QByte array
                     QString sur = HexToFloat(nur);

                     QString fur= " ";//declaration of string
                     fur+= "\n Imaginary::Part #2:   "+sur;// definition of string


                      float im_2 = sur.toFloat(&valid);
                      arg_1 = re_2*re_2+im_2*im_2;
                      arg_2 = re_2/im_2;

                       mag_2 = qSqrt(arg_1);


                      fi_2 = (ratio)*(qAtan(arg_2));



                     QString lad =j.mid(64,8);//picking values from index  upto  indexes and storing those into string
                      QByteArray bad= lad.toUtf8();//converting string  into a QByte array
                      QString sad = HexToFloat(bad);

                      QString dad= " ";//declaration of string
                      dad+= "\n Real::Part #3:   "+sad;// definition of string

                          float re_3 = sad.toFloat(&valid);


                      QString nad =j.mid(72,8);//picking values from index upto indexes and storing those into string
                       QByteArray mad= nad.toUtf8();//converting string  into a QByte array
                       QString kad = HexToFloat(mad);

                       QString jad= " ";//declaration of string
                       jad+= "\n Imaginary::Part #3:   "+kad;// definition of string

                       float im_3 = kad.toFloat(&valid);
                       arg_1 = re_3*re_3+im_3*im_3;
                       arg_2 = re_3/im_3;


                        mag_3 = qSqrt(arg_1);


                        fi_3 =(ratio)*(qAtan(arg_2));

                       QString wr=j.mid(80,8);
                       QByteArray lk= wr.toUtf8();//converting string into a QByte array
                       sk = HexToFloat(lk);
                       QString qr=" ";
                       qr+= "\nFrequency (Floating Point) IEEE 754 Standard: "+sk;
                        freq = sk.toFloat(&valid);


                       QString wt=j.mid(88,8);
                       QByteArray to= wt.toUtf8();//converting string  into a QByte array
                       QString mo = HexToFloat(to);
                        QString qt=" ";
                        qt+= "\nDFREQ / ROCOF:  "+mo;



                        QString lol=j.mid(96,8);
                        QByteArray kop= lol.toUtf8();//converting string  into a QByte array
                        QString set = HexToFloat(kop);
                         QString bt=" ";
                         bt+= "\nAnalog Value #1: "+set;

                          an_1 = set.toFloat(&valid);

                         QString sop=j.mid(104,8);
                         QByteArray pos= sop.toUtf8();//converting string  into a QByte array
                         QString mom = HexToFloat(pos);
                          QString son=" ";
                          son+= "\nAnalog Value #2: "+mom;

                          an_2 = mom.toFloat(&valid);



                        QString y= "";
                        y+="\nCheckSum:  0x"+j[112]+j[113]+j[114]+j[115];

 ui->listWidget->clear();

                       ui->listWidget->addItem(s+q+w+ipd+frcsec3+bgf+sdf+mju+fur+dad+jad+qr+qt+bt+son+y/*+HexToAscii(st))*/);

             }


   }       else  {
   // bool valid= true;
         /*----------------------------for configuration frames--------------------------------------*/

           QString oa= "";
           oa+="Synchronisation Word:  "+j[0]+j[1]+j[2]+j[3];
           sync_word = oa;

               ui->label_3->setText("\n Configuration frame recieved\n streaming data frames");



           QString ob =j.mid(4,4);//picking values from index 4 upto 4 indexes and storing those into string

            QByteArray oc= ob.toUtf8();// converting string  into a QByte array
            QString od=QString::number(oc.toLongLong(&valid,16));//fnc returns int values & get stored into string
            QString oe= " ";//declaration of string
            oe+= "\nFrame Size:  "+od;// definition of string
            frame_size = oe;

            QString of =j.mid(8,4);//picking values from index 8 upto 4 indexes and storing those into string
             QByteArray og= of.toUtf8();//converting string  into a QByte array
             QString oh=QString::number(og.toLongLong(&valid,16));//fnc returns int values & get stored into string
             QString oi= " ";//declaration of string
             oi+= "\nPMU/DC ID Number:  "+oh;// definition of string
             pmu_id = oi;
                           //timeStamp
             QString oj =j.mid(22,6);//picking values from index  upto  indexes and storing those into string
              QByteArray ol= oj.toUtf8();//converting string  into a QByte array
              QString om=QString::number(ol.toLongLong(&valid,16));//fnc returns int values & get stored into string
              QString on= " ";//declaration of string
              on+= "\nFraction Of Second (raw):  "+om;// definition of string
               foc = on;
              QString op =j.mid(30,6);//picking values from index  upto  indexes and storing those into string
               QByteArray oq= op.toUtf8();//converting string into a QByte array
               QString oz=QString::number(oq.toLongLong(&valid,16));//fnc returns int values & get stored into string
               QString os= " ";//declaration of string
               os+= "\nResolution Of Fractional Second TimeStamp:  "+oz;// definition of string
                  rofst = os;

                QString ot =j.mid(36,4);//picking values from index upto  indexes and storing those into string
                QByteArray ou= ot.toUtf8();//converting string  into a QByte array
                QString ov=QString::number(ou.toLongLong(&valid,16));//fnc returns int values & get stored into string
                QString oy= " ";//declaration of string
                oy+= "\nNumber Of PMU Blocks Included In The Frame:  "+ov;// definition of string
                    pmu_blocks = oy;

                    QString ea =j.mid(40,32);//picking values from index  upto  indexes and storing those into string

                 QString eb = HexToAscii(ea);
                QString ec= " ";//declaration of string
                 ec+= "\nStation Name:  "+eb;// definition of string
                 station_name = ec;

                 QString ed =j.mid(72,4);//picking values from index  upto  indexes and storing those into string
                  QByteArray ef= ed.toUtf8();//converting string into a QByte array
                  QString eg=QString::number(ef.toLongLong(&valid,16));//fnc returns int values & get stored into string
                  QString eh= " ";//declaration of string
                  eh+= "\nPMU/DC ID Number:  "+eg;// definition of string
                   xyz =  eh;

                   QString lll =j.mid(79,1);
                    QByteArray re = lll.toUtf8();

                    mb = re.toLongLong(&valid,16);
                    QString frmt= " ";


                 if (mb == 0) {
                     frmt+= "\nFormat: Rectangular Fixed Point::Analog Fixed Point::Frequency Fixed Point ";
                 } else if  (mb == 14)  {

                         //QString jz= " ";
                         frmt+="\nFormat: Rectangular(Float)::Analog(Float):: Frequency(Float) ";
                     } else if (mb == 1) {

                             //QString jz= " ";
                             frmt+="\nFormat:Polar Fixed Point::Analog Fixed Point::Frequency Fixed Point ";
                            } else  if (mb == 15) {

                                 //QString jz= " ";
                                 frmt+="\nFormat: Polar(Float)::Analog(Float):: Frequency(Float) ";

                             } else {

                 }





                      jzz = jz;


                 qDebug() << mb;
                 qDebug() << jzz;


      QString ei =j.mid(80,4);//picking values from index  upto  indexes and storing those into string
                   QByteArray ej= ei.toUtf8();//converting string  into a QByte array
                   QString el=QString::number(ej.toLongLong(&valid,16));//fnc returns int values & get stored into string
                   QString em= " ";//declaration of string
                   em+= "\nNumber Of Phasors:  "+el;// definition of string
                       num_phsr = em;
                       nd = el.toFloat(&valid);

                       QString en =j.mid(84,4);//picking values from index  upto  indexes and storing those into string
                    QByteArray eo= en.toUtf8();//converting string  into a QByte array
                    QString ep=QString::number(eo.toLongLong(&valid,16));//fnc returns int values & get stored into string
                    QString eq= " ";//declaration of string
                    eq+= "\nNumber of Analog Values:  "+ep;// definition of string
                         num_an = eq;

                         QString er =j.mid(88,4);//picking values from index  upto  indexes and storing those into string
                     QByteArray es= er.toUtf8();//converting string  into a QByte array
                     QString et=QString::number(es.toLongLong(&valid,16));//fnc returns int values & get stored into string
                     QString eu= " ";//declaration of string
                     eu+= "\nNumber OF Digital Status words:  "+et;// definition of string
                           num_dig = eu;

                           QString ev =j.mid(92,32);//picking values from index  upto  indexes and storing those into string

                      QString ex = HexToAscii(ev);
                     QString ey= " ";//declaration of string
                      ey+= "\nPhasor Name #1:  "+ex;// definition of string
                          phsr_name_1 = ey;
                          phsr_name_01 =ex;

                          QString fa =j.mid(124,32);//picking values from index  upto  indexes and storing those into string

                       QString fb = HexToAscii(fa);
                      QString fc= " ";//declaration of string
                       fc+= "\nPhasor Name #2:  "+fb;// definition of string
                        phsr_name_2 = fc;
                        phsr_name_02 = fb;

                        QString fd =j.mid(156,32);//picking values from index  upto  indexes and storing those into string

                        QString fe = HexToAscii(fd);
                       QString ff= " ";//declaration of string
                        ff+= "\nPhasor Name #3:  "+fe;// definition of string
                           phsr_name_3 = ff;
                            phsr_name_03 = fe;

                           QString fi =j.mid(188,32);//picking values from index  upto  indexes and storing those into string

                         QString fj = HexToAscii(fi);
                        QString fk= " ";//declaration of string
                         fk+= "\nAnalog Value #1:  "+fj;// definition of string
                         an_name_1 = fk;
                          an_name_01 = fj;

                         QString fl =j.mid(220,32);//picking values from index  upto  indexes and storing those into string

                          QString fm = HexToAscii(fl);
                         QString fn= " ";//declaration of string w
                          fn+= "\nAnalog Value #2:  "+fm;// definition of string
                           an_name_2 = fn;
                           an_name_02 = fm;

                          QString fo =j.mid(252,8);//picking values from index  upto  indexes and storing those into string
                           QByteArray fp= fo.toUtf8();//converting string into a QByte array
                           QString fq=QString::number(fp.toLongLong(&valid,16));//fnc returns int values & get stored into string
                           QString fr= " ";//declaration of string
                           fr+= "\nPhasor Coversion Factor #1:  "+fq +" * 10^-5 Volts (FIXED POINT)::  "+fq+"  (FLOATING POINT)";// definition of string
                              phsr_con_fctr_1 = fr;

                           QString fs =j.mid(260,8);//picking values from index  upto  indexes and storing those into string
                            QByteArray ft= fs.toUtf8();//converting string  into a QByte array
                            QString fu=QString::number(ft.toLongLong(&valid,16));//fnc returns int values & get stored into string
                            QString fv= " ";//declaration of string
                            fv+= "\nPhasor Coversion Factor #2:  "+fu +" * 10^-5 Volts (FIXED POINT)::"+fu+"   (FLOATING POINT)";// definition of string
                            phsr_con_fctr_2 = fv;

                            QString fw =j.mid(268,8);//picking values from index 8 upto 4 indexes and storing those into string sd
                             QByteArray fx= fw.toUtf8();//converting string sd into a QByte array zd
                             QString fy=QString::number(fx.toLongLong(&valid,16));//fnc returns int values & get stored into string id
                             QString fz= " ";//declaration of string w
                             fz+= "\nPhasor Coversion Factor #3:  "+fy +" * 10^-5  Volts (FIXED POINT)::"+fy+"  (FLOATING POINT)";// definition of string
                              phsr_con_fctr_3 = fz;
                             QString ga =j.mid(280,4);//picking values from index  upto  indexes and storing those into string
                              QByteArray gb= ga.toUtf8();//converting string  into a QByte array
                              QString gc=QString::number(gb.toLongLong(&valid,16));//fnc returns int values & get stored into string
                              QString gd= " ";//declaration of string
                              gd+= "\nAnalog Value Conversion Factor #1 : RMS of Analog Input, Value: "+gc;// definition of string
                              an_con_fctr_1 = gd;


                              QString ge =j.mid(288,4);//picking values from index upto  indexes and storing those into string
                               QByteArray gf= ge.toUtf8();//converting string  into a QByte array
                               QString gg=QString::number(gf.toLongLong(&valid,16));//fnc returns int values & get stored into string
                               QString gh= " ";//declaration of string
                               gh+= "\nAnalog Value Conversion Factor #2 : RMS of Analog Input, Value: "+gg;// definition of string
                               an_con_fctr_2 =gh;


                               QString gi =j.mid(300,4);//picking values from index upto indexes and storing those into string
                                QByteArray gj= gi.toUtf8();//converting string  into a QByte array
                                QString gk=QString::number(gj.toLongLong(&valid,16));//fnc returns int values & get stored into string
                                QString gl= " ";//declaration of string
                                gl+= "\nRate Of Transmission : "+gk+" Frame(s) Per Second" ;// definition of string
                                 r_o_t = srt;
                                QString gm= "";
                                gm+="\nCheckSum:  0x"+j[304]+j[305]+j[306]+j[307];
                                chksum =gm;


    }
           }
       });



}
//******************************************************Data parsing ends here*********************************************************


// *********************************Definitions of some user defined funnctions **************************************************************//

QString HexToFloat(QByteArray z){
    //qDebug<<"z";
    bool ok=true;
       int sign = 1;
       //qDebug()<<"lala"<<z.length();
       z = QByteArray::number(z.toLongLong(&ok,16),2);
       if(z.length()==32) {
           //qDebug()<<z.length();
           if(z.at(0)=='1')  sign =-1;                       // if bit 0 is 1 number is negative
           z.remove(0,1);                                     // remove sign bit
       }
       QByteArray fraction =z.right(23);   //get the fractional part
       //qDebug()<< fraction;
       double mantissa = 0;
       for(int i=0;i<fraction.length();i++)     // iterate through the array to calculate the fraction as a decimal.
           if(fraction.at(i)=='1')     mantissa += 1.0/(pow(2,i+1));

       int exponent = z.left(z.length()-23).toLongLong(&ok,2)-127;     //calculate the exponent
       //qDebug()<<mantissa<<",  "<<exponent;
        QString st=QString::number( sign*pow(2,exponent)*(mantissa+1.0),'f', 18);
           //qDebug()<<"lala"<<st;
           return st;
}

QString HexToAscii(QString String)

{

QByteArray ByteArray1=String.toUtf8();

const char* chArr1=ByteArray1.constData();

QByteArray ByteArray2=QByteArray::fromHex(chArr1);

const char* chArr2=ByteArray2.constData();

return QString::fromUtf8(chArr2);

}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::mytime(){
    QTime time = QTime::currentTime();
     QString all_time = time.toString("hh:mm:ss");
    QString time_text = time.toString("hhmmss");

    bool valid =true;

    QString ssd= time_text.mid(0,6);

  //  ui->date_time->setText(ssd);
    ui->lcdNumber->display(all_time);
    QPalette Pal = ui->lcdNumber->palette();
    Pal.setColor(QPalette::Normal, QPalette::WindowText, Qt::green);
    Pal.setColor(QPalette::Normal, QPalette::Window, Qt::black);
    ui->lcdNumber->setPalette(Pal);
    // ui->lcdNumber->setPalette(Qt::red);
unsigned long int jjh= ssd.toULong(&valid);
ssh= jjh;
fctr2 = (frcsec4) / (16777215);
time_stamp = ssh + fctr2;
qDebug() << fctr2 << "fctr2" << time_stamp << "timestamp";

}

void MainWindow::on_connect_clicked()
{
    //std::cout<< "ok";
    mSocket->bind(ui->port->value(), QUdpSocket::ShareAddress);
    if(ui->port->value() == 9000){
    QMessageBox::about(this,"Alert !", "Connection Successful");
    ui->label_3->setText("iTester on Listening mode..\n Waiting for reception of Configuration Frame...");
    ui->connect->setEnabled(false);
    } else {

         QMessageBox::about(this,"Alert !", "Connection Not Successful\n Please Enter a Valid Port Address");




    }

    //std::cout<< "not ok";

}






void MainWindow::on_pushButton_clicked()
{

   ui->listWidget_3->addItem(sync_word + frame_size+ pmu_id+ipd+ foc+ rofst+ pmu_blocks+ station_name+ frmt+ num_phsr+ num_an+ num_dig+ phsr_name_1+ phsr_name_2+ phsr_name_3+an_name_1+ an_name_2+
                             phsr_con_fctr_1+ phsr_con_fctr_2+ phsr_con_fctr_3+ an_con_fctr_1+ an_con_fctr_2+r_o_t + chksum);

}




//***********************************************functions for data plotiing are defined below****************************//



void MainWindow::setupRealtimeDataDemo(QCustomPlot *customPlot)
{


  customPlot->addGraph(); // blue line
   QPen pen;
  pen.setWidth(5);
  pen.setColor(QColor(23,300,180));
  customPlot->graph(0)->setPen(pen);
 // customPlot->graph(0)->setPen(QPen(QColor(40, 110, 255)));
  customPlot->addGraph(); // red line
  QPen pen1;
 pen1.setWidth(5);
 pen1.setColor(QColor(225,110,225));
 customPlot->graph(1)->setPen(pen1);
 customPlot->addGraph(); // red line
 QPen pen2;
pen2.setWidth(5);
pen2.setColor(QColor(50,190,105));
customPlot->graph(2)->setPen(pen2);

  customPlot->axisRect()->setupFullAxesBox();
  customPlot->yAxis->setRange(-10000, 10000);



  // make left and bottom axes transfer their ranges to right and top axes:
  connect(customPlot->xAxis, SIGNAL(rangeChanged(QCPRange)), customPlot->xAxis2, SLOT(setRange(QCPRange)));
  connect(customPlot->yAxis, SIGNAL(rangeChanged(QCPRange)), customPlot->yAxis2, SLOT(setRange(QCPRange)));

  // setup a timer that repeatedly calls MainWindow::realtimeDataSlot:
  connect(&dataTimer, SIGNAL(timeout()), this, SLOT(realtimeDataSlot()));
  dataTimer.start(0); // Interval 0 means to refresh as fast as possible
}
void MainWindow::realtimeDataSlot()
{

  double key = ssh; // time elapsed since start of demo, in seconds
  static double lastPointKey = 0;
 // qDebug() << key;
  if (key-lastPointKey >.000000001) // at most add point every 2 ms
  {
    // add data to lines:
   // ui->customPlot->graph(0)->addData(key, mag_1);

             ui->customPlot->graph(0)->addData(key,mag_1);







             ui->customPlot->graph(1)->addData(key,mag_2);




                     ui->customPlot->graph(2)->addData(key,mag_3);
                      ui->customPlot->replot();
        }



 ui-> customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);



    lastPointKey = key;

  // make key axis range scroll with the data (at a constant range size of ):
    ui->customPlot->yAxis->setLabelFont( QFont(QFont().family(), 10) );
    ui->customPlot->yAxis->setLabel("Magnitude (kV / A)");
  ui->customPlot->xAxis->setRange(key, 300, Qt::AlignRight);
  ui->customPlot->replot();
  ui->customPlot->graph(0)->setName(phsr_name_1);
   ui->customPlot->graph(1)->setName(phsr_name_2);
    ui->customPlot->graph(2)->setName(phsr_name_3);

    ui->customPlot->legend->setVisible(true);
    ui->customPlot->legend->setBrush(QColor( 255, 255, 255));



  mag__min = ui->mag_min->value();
  mag__max = ui->mag_max->value();

}


void MainWindow::setupRealtimeDataDemo1(QCustomPlot *customPlot1)
{


  customPlot1->addGraph(); // blue line
   QPen pen;
  pen.setWidth(5);
  pen.setColor(QColor(23,300,180));
  customPlot1->graph(0)->setPen(pen);
 // customPlot->graph(0)->setPen(QPen(QColor(40, 110, 255)));
  customPlot1->addGraph(); // red line
  QPen pen1;
 pen1.setWidth(5);
 pen1.setColor(QColor(225,110,225));
 customPlot1->graph(1)->setPen(pen1);
 customPlot1->addGraph(); // red line
 QPen pen2;
pen2.setWidth(5);
pen2.setColor(QColor(50,190,105));
customPlot1->graph(2)->setPen(pen2);

  customPlot1->axisRect()->setupFullAxesBox();
  customPlot1->yAxis->setRange(-180, 180);

  // make left and bottom axes transfer their ranges to right and top axes:
  connect(customPlot1->xAxis, SIGNAL(rangeChanged(QCPRange)), customPlot1->xAxis2, SLOT(setRange(QCPRange)));
  connect(customPlot1->yAxis, SIGNAL(rangeChanged(QCPRange)), customPlot1->yAxis2, SLOT(setRange(QCPRange)));

  // setup a timer that repeatedly calls MainWindow::realtimeDataSlot:
  connect(&dataTimer, SIGNAL(timeout()), this, SLOT(realtimeDataSlot1()));
  dataTimer.start(0); // Interval 0 means to refresh as fast as possible
}
void MainWindow::realtimeDataSlot1()
{

  double key = ssh; // time elapsed since start of demo, in seconds
  static double lastPointKey = 0;
 // qDebug() << key;
  if (key-lastPointKey > .000000000000000000000000000000001) // at most add point every 2 ms
  {


               ui->customPlot1->graph(0)->addData(key,fi_1);




               ui->customPlot1->graph(1)->addData(key,fi_2);





                       ui->customPlot1->graph(2)->addData(key,fi_3);


ui->customPlot1->replot();

    }
    // add data to lines:

 ui-> customPlot1->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);


    lastPointKey = key;

  // make key axis range scroll with the data (at a constant range size of 8):
    ui->customPlot1->yAxis->setLabelFont( QFont(QFont().family(), 10) );
    ui->customPlot1->yAxis->setLabel("Angle (Degrees)");
  ui->customPlot1->xAxis->setRange(key, 300, Qt::AlignRight);
  ui->customPlot1->replot();
  ui->customPlot1->graph(0)->setName(phsr_name_1);
   ui->customPlot1->graph(1)->setName(phsr_name_2);
    ui->customPlot1->graph(2)->setName(phsr_name_3);

  ui->customPlot1->legend->setVisible(true);
  ui->customPlot1->legend->setBrush(QColor( 255, 255, 255));
//ui->customPlot1->setStyleSheet("border: 2px solid blue");



  ang__min = ui->ang_min->value();
  ang__max = ui->ang_max->value();


}


void MainWindow::setupRealtimeDataDemo2(QCustomPlot *customPlot2)
{


  customPlot2->addGraph(); // blue line
   QPen pen;
  pen.setWidth(5);
  pen.setColor(QColor(23,300,180));
  customPlot2->graph(0)->setPen(pen);
 // customPlot->graph(0)->setPen(QPen(QColor(40, 110, 255)));
  customPlot2->addGraph(); // red line
  QPen pen1;
 pen1.setWidth(5);
 pen1.setColor(QColor(225,110,225));
 customPlot2->graph(1)->setPen(pen1);
 customPlot2->addGraph(); // red line


  customPlot2->axisRect()->setupFullAxesBox();
  customPlot2->yAxis->setRange(-400, 400);

  // make left and bottom axes transfer their ranges to right and top axes:
  connect(customPlot2->xAxis, SIGNAL(rangeChanged(QCPRange)), customPlot2->xAxis2, SLOT(setRange(QCPRange)));
  connect(customPlot2->yAxis, SIGNAL(rangeChanged(QCPRange)), customPlot2->yAxis2, SLOT(setRange(QCPRange)));

  // setup a timer that repeatedly calls MainWindow::realtimeDataSlot:
  connect(&dataTimer, SIGNAL(timeout()), this, SLOT(realtimeDataSlot2()));
  dataTimer.start(0); // Interval 0 means to refresh as fast as possible
}
void MainWindow::realtimeDataSlot2()
{

  double key = ssh; // time elapsed since start of demo, in seconds
  static double lastPointKey = 0;
 // qDebug() << key;
  if (key-lastPointKey > .000000000000000000000000000000000001) // at most add point every 2 ms
  {


               ui->customPlot2->graph(0)->addData(key,an_1);






               ui->customPlot2->graph(1)->addData(key,an_2);
                  ui->customPlot2->replot();





        }
    // add data to lines:

 ui-> customPlot2->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);

    lastPointKey = key;

  // make key axis range scroll with the data (at a constant range size of 8):
    ui->customPlot2->yAxis->setLabelFont( QFont(QFont().family(), 10) );

    ui->customPlot2->yAxis->setLabel("Analog (RMS)");
  ui->customPlot2->xAxis->setRange(key, 300, Qt::AlignRight);
  ui->customPlot2->replot();
  ui->customPlot2->graph(0)->setName(an_name_1);
   ui->customPlot2->graph(1)->setName(an_name_2);

  ui->customPlot2->legend->setVisible(true);
  ui->customPlot2->legend->setBrush(QColor( 255, 255, 255));



  an__min = ui->an_min->value();
  an__max = ui->an_max->value();


}



void MainWindow::setupRealtimeDataDemo3(QCustomPlot *customPlot3)
{

  customPlot3->addGraph(); // blue line
   QPen pen;
  pen.setWidth(5);
  pen.setColor(QColor(23,300,180));
  customPlot3->graph(0)->setPen(pen);
 // customPlot->graph(0)->setPen(QPen(QColor(40, 110, 255)));
  customPlot3->addGraph(); // red line

  customPlot3->axisRect()->setupFullAxesBox();
  customPlot3->yAxis->setRange(49.9, 50.1);

  // make left and bottom axes transfer their ranges to right and top axes:
  connect(customPlot3->xAxis, SIGNAL(rangeChanged(QCPRange)), customPlot3->xAxis2, SLOT(setRange(QCPRange)));
  connect(customPlot3->yAxis, SIGNAL(rangeChanged(QCPRange)), customPlot3->yAxis2, SLOT(setRange(QCPRange)));

  // setup a timer that repeatedly calls MainWindow::realtimeDataSlot:
  connect(&dataTimer, SIGNAL(timeout()), this, SLOT(realtimeDataSlot3()));
  dataTimer.start(0); // Interval 0 means to refresh as fast as possible
}
void MainWindow::realtimeDataSlot3()
{
  //static QTime time(QTime::currentTime());
  // calculate two new data points:
  float key = time_stamp; // time elapsed since start of demo, in seconds
  static double lastPointKey = 0;
 // qDebug() << key;
  if (key-lastPointKey > 0.00000000000000001) // at most add point every 2 ms

       ui->customPlot3->graph(0)->addData(key,freq);


 ui-> customPlot3->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);

    lastPointKey = key;

  // make key axis range scroll with the data (at a constant range size of 8):
    ui->customPlot3->yAxis->setLabelFont( QFont(QFont().family(), 10) );
    ui->customPlot3->yAxis->setLabel("Frequency (Hz)");

  ui->customPlot3->xAxis->setRange(key, 300, Qt::AlignRight);
  ui->customPlot3->replot();



}




void MainWindow::on_actionAbout_triggered()
{
  QMessageBox::information(this,"About iTester", "iTester Version 1.0\n\n Designed to handle a specific case of 3 Phasors, 2 Analogs and zero Digitals (Floating Point) with a data rate  of 1 frame per second. \n\niTestor version 1.0 is under development and hence manages to handle specific case only.  \n\n Created by Faizan Bhatt (University Of Kashmir). \n\nFor any queries feel free to contact <faizanbhatt427@gmail.com>.                                                     \n\nDone under the supervision of                                                                                          PROF. ANIL M KULKARNI at EE-IIT BOMBAY\n\n  Acknowledgement:  \n\n1. GNANA VINAYAGAN\n\n  2. SANTOSH V.SINGH (EE-IITB) ");

}

//*******************************************system defined functions for different widgets ***********************************//

void MainWindow::on_rescale_clicked()
{
      ui->customPlot->yAxis->setRange(-1000000, 1000000);
}

void MainWindow::on_resize1_clicked()
{
      ui->customPlot1->yAxis->setRange(-180, 180);
}

void MainWindow::on_resize2_clicked()
{
      ui->customPlot2->yAxis->setRange(-100000, 100000);
}

void MainWindow::on_resize3_clicked()
{
      ui->customPlot3->yAxis->setRange(49.9,50.1);
}

void MainWindow::on_pushButton_2_clicked()
{
   ui->customPlot->yAxis->setRange(mag__min, mag__max);
}

void MainWindow::on_pushButton_3_clicked()
{
    ui->customPlot1->yAxis->setRange(ang__min, ang__max);
}

void MainWindow::on_pushButton_4_clicked()
{
    ui->customPlot2->yAxis->setRange(an__min, an__max);
}


void MainWindow::on_pushButton_5_clicked()
{
    close();
}
